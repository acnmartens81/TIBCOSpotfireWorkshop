The SAP Hana adapter is built specifically for use within the TIBCO Data Virtualization platform.  
To use the adapter, first deploy it to the TDV platform.


********************************************
*   Deploying the SAP Hana Adapter   *
********************************************

To deploy the adapter, you can execute the server_util utility via the command line by

1. Extract the tdv.SAPHANA folder to the location of your choice.
2. Open a command prompt window.
3. Navigate to the <TDV_install_dir>/bin
4. Enter the server_util command with the -deploy option (note: package location is dependent upon the chosen extraction location):

server_util -server <hostname> [-port <port>] -user <user> -password <password> -deploy -package <unzipped_file_location>/tdv.saphana/tdv.saphana.jar



Note: When deploying a build of an existing adapter, you will need to undeploy the existing adapter using the server_util command with the -undeploy option.

server_util -server <hostname> [-port <port>] -user <user> -password <password> -undeploy -version 1 -name SAPHana


**************************************************************
*   Additonal Information about the SAP Hana Adapter   *
**************************************************************

Additional information about the adapter, getting connected, and supported capabilities can be found in the help.htm file contained within the help directory.